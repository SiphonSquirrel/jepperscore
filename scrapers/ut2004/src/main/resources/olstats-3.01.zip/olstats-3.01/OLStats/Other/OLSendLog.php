<?php

/*
Possible return codes:
R1 OK
R2 Bad Password
R3 No filename specified
R4 No data sent
R5 Could not create logfile
R6

*/

echo "OLStatsSendLogTarget\n";

error_reporting(0);
require("config.inc.php");


function check_get($val)
{
  $magic = get_magic_quotes_gpc();
  if (isset($_GET["$val"])) {
    if ($magic)
      $store = stripslashes($_GET["$val"]);
    else
      $store = $_GET["$val"];
    if ($store)
      return $store;
    return 1;
  }
  return 0;
}

function check_post($val)
{
  $magic = get_magic_quotes_gpc();
  if (isset($_POST["$val"])) {
    if ($magic)
      $store = stripslashes($_POST["$val"]);
    else
      $store = $_POST["$val"];
    if ($store)
      return $store;
    return 1;
  }
  return 0;
}

function footer()
{
	// There is a bug in LibHTTP2 that makes it so the last couple
	// lines sometimes do not come through, so I add buffer to the
	// end of the output to fix that.
	echo "\nBuffer\nBuffer\nBuffer";
}

$password = $filename = $data = "";

$password = check_post("pass");
$filename = check_post("filename");
$data = check_post("data");

if ($password == "" || $AdminPass == "" || $password != $AdminPass) {
  echo "2";
  footer();
  exit;
}

if ($filename === 0)
{
	echo "3";
	footer();
	exit;
}
if ($data === 0)
{
	echo "4";
	footer();
	exit;
}

$filename = $logpath1.$filename.".log";

$f = fopen($filename,"w");
fwrite($f,$data,strlen($data));
echo "1";
footer();

fclose($f);

?>